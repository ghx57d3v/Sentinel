#!/bin/bash
set -e
echo "[developer] Developer profile applied (tooling + Docker disabled)."
