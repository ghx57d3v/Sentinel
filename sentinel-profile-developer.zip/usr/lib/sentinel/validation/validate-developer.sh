#!/bin/bash
EXIT=0

# Ensure Sentinel core firewall input remains drop
if nft list chain inet sentinel core_input 2>/dev/null | grep -q "policy drop"; then
  true
else
  echo "FAIL: core_input policy not drop"
  EXIT=21
fi

# Ensure docker is not active (developer profile prefers podman)
if systemctl is-active --quiet docker 2>/dev/null; then
  echo "FAIL: docker service active"
  EXIT=22
fi

# Ensure podman installed
if ! command -v podman >/dev/null 2>&1; then
  echo "FAIL: podman missing"
  EXIT=23
fi

# Check for obvious public listeners (0.0.0.0)
if command -v ss >/dev/null 2>&1; then
  if ss -lntup 2>/dev/null | grep -E "0\.0\.0\.0:" -q; then
    echo "WARN: public listener detected (review required)"
  fi
fi

exit $EXIT
