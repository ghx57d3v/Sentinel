#!/bin/bash
set -e

# Apply REM rules into Sentinel Core override chain.
# Safe to run multiple times.

if ! nft list tables 2>/dev/null | grep -q "inet sentinel"; then
  echo "[rem] Sentinel Core nft table missing; cannot apply REM rules."
  exit 1
fi

nft -f /etc/sentinel/profiles/rem.nft
echo "[rem] REM egress policy applied."
