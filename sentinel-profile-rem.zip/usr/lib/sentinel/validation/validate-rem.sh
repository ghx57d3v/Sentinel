#!/bin/bash
EXIT=0

# Ensure Sentinel nft table exists
if ! nft list tables 2>/dev/null | grep -q "inet sentinel"; then
  echo "FAIL: sentinel nftables table missing"
  exit 11
fi

# Ensure REM drop enforcement is present in override output
if ! nft list chain inet sentinel profile_override_output 2>/dev/null | grep -q "jump log_and_drop"; then
  echo "FAIL: REM override_output does not enforce drop"
  EXIT=18
fi

# Ensure clearnet DNS is not allowed (no udp/tcp dport 53 accept)
if nft list chain inet sentinel profile_override_output 2>/dev/null | grep -E "dport 53.*accept" -q; then
  echo "FAIL: clearnet DNS appears allowed"
  EXIT=18
fi

# Ensure Tor is running (best-effort)
if ! systemctl is-active --quiet tor 2>/dev/null; then
  echo "FAIL: tor service not active"
  EXIT=19
fi

exit $EXIT
