#!/bin/bash
EXIT=0

if ! aa-status 2>/dev/null | grep -q "profiles are in enforce mode"; then
    echo "FAIL: AppArmor not enforcing"
    EXIT=12
fi

if ! nft list tables 2>/dev/null | grep -q "inet sentinel"; then
    echo "FAIL: sentinel nftables table missing"
    EXIT=11
fi

if ! systemctl is-active --quiet auditd; then
    echo "FAIL: auditd not active"
    EXIT=13
fi

if ! sysctl kernel.dmesg_restrict | grep -q "1"; then
    echo "FAIL: sysctl baseline not applied"
    EXIT=14
fi

exit $EXIT
